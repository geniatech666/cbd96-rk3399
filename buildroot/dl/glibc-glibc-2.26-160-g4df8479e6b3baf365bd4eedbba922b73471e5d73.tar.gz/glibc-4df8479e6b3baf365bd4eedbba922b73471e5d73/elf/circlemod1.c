extern int circlemod2 (void);

int
circlemod1 (void)
{
  return circlemod2 ();
}
