/* This file should contain any system-dependent functions
   that will be used by many parts of the library.  */
